module.exports = {
    appId: 'com.example.linuxguiapp',
    productName: 'Linux GUI App',
    main: 'src/main.js',
    directories: {
        output: 'dist'
    },
    win: {
        icon: 'assets/icon.ico',
        target: [
            {
                target: 'nsis',
                arch: ['x64', 'ia32']
            }
        ]
    },
    mac: {
        icon: 'assets/icon.icns',
        target: 'dmg'
    },
    linux: {
        icon: 'assets/icon.png',
        target: [
            {
                target: 'AppImage',
                arch: ['x64', 'armv7l', 'arm64']
            }
        ]
    },
    publish: {
        provider: 'generic',
        url: 'https://your-update-server.com/'
    },
    window: {
        width: 800,
        height: 600,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false
        }
    }
};