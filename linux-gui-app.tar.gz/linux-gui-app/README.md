# Linux GUI Application for Bash Command Execution

This project is a graphical user interface (GUI) application designed to simplify the management of Linux systems by allowing users to execute Bash commands without using the command line. The application is built using Electron, providing a cross-platform desktop experience.

## Features

- Execute Bash commands through a user-friendly interface.
- View command output directly within the application.
- Simplified management of Linux tasks without the need for terminal knowledge.

## Project Structure

```
linux-gui-app
├── src
│   ├── main.js              # Main entry point for the Electron application
│   ├── renderer.js          # Manages rendering and user interactions
│   ├── components
│   │   └── CommandExecutor.js # Handles command execution logic
│   └── utils
│       └── bashRunner.js    # Utility for running Bash commands
├── package.json             # npm configuration file
├── electron.config.js       # Electron application configuration
└── README.md                # Project documentation
```

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   cd linux-gui-app
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Run the application:
   ```
   npm start
   ```

## Usage

- Launch the application to access the GUI.
- Enter the desired Bash command in the input field.
- Click the "Execute" button to run the command.
- View the output displayed in the designated area of the interface.

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any enhancements or bug fixes.

## License

This project is licensed under the MIT License. See the LICENSE file for details.