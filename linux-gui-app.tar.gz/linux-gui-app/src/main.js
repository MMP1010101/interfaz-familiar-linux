const { app, BrowserWindow } = require('electron');
const path = require('path');

let mainWindow;

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1000,
        height: 700,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false,
            enableRemoteModule: false,
        },
        icon: path.join(__dirname, '../assets/icon.png'), // opcional
        title: 'Linux GUI - Ejecutor de Comandos Bash'
    });

    mainWindow.loadFile('index.html');

    // Abrir DevTools para debug
    mainWindow.webContents.openDevTools();

    mainWindow.webContents.on('crashed', () => {
        console.log('La ventana se crasheó');
    });

    mainWindow.webContents.on('did-fail-load', (event, errorCode, errorDescription) => {
        console.log('Error al cargar:', errorCode, errorDescription);
    });

    mainWindow.on('closed', () => {
        mainWindow = null;
    });
}

app.on('ready', createWindow);

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

app.on('activate', () => {
    if (mainWindow === null) {
        createWindow();
    }
});