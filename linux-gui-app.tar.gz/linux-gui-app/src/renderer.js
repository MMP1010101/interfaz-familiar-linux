// Cargar módulos usando require absoluto
const { exec } = require('child_process');

// Crear función para ejecutar comandos directamente
function runBashCommand(command) {
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                reject(new Error(`Error: ${error.message}`));
                return;
            }
            if (stderr) {
                reject(new Error(`Stderr: ${stderr}`));
                return;
            }
            resolve(stdout.trim());
        });
    });
}

document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM cargado correctamente');
    
    const button = document.getElementById('execute-button');
    const input = document.getElementById('command-input');
    const output = document.getElementById('output');
    
    if (!button || !input || !output) {
        console.error('No se encontraron los elementos del DOM');
        return;
    }
    
    button.addEventListener('click', async () => {
        const commandInput = input.value.trim();
        
        if (!commandInput) {
            output.innerText = 'Por favor, ingresa un comando.';
            return;
        }
        
        output.innerText = 'Ejecutando comando...';
        console.log('Ejecutando comando:', commandInput);
        
        try {
            const result = await runBashCommand(commandInput);
            output.innerText = result || 'Comando ejecutado sin salida.';
            console.log('Resultado:', result);
        } catch (error) {
            output.innerText = `Error: ${error.message}`;
            console.error('Error ejecutando comando:', error);
        }
    });
    
    // Permitir ejecutar con Enter
    input.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            button.click();
        }
    });
});