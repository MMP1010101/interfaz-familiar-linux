class CommandExecutor {
    constructor() {
        this.output = '';
    }

    async executeCommand(command) {
        const path = require('path');
        const runBashCommand = require(path.resolve(__dirname, '..', 'utils', 'bashRunner'));
        try {
            this.output = await runBashCommand(command);
            return this.output;
        } catch (error) {
            throw error;
        }
    }

    getCommandOutput() {
        return this.output;
    }
}

module.exports = CommandExecutor;